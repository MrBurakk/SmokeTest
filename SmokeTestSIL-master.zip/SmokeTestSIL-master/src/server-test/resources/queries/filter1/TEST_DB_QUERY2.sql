select 2 as other_test_column
from other_no_such_table onst
where onst.id = 2 -- another dummy sql comment