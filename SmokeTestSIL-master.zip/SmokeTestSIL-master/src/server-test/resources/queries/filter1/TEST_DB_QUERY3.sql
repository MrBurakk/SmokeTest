select 3 as yet_another_test_column
from yet_another_no_such_table yanst
where yanst.id = 3 -- yet another dummy sql comment