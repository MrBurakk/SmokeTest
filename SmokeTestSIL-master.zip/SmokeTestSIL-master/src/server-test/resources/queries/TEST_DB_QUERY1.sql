select 1 as test_column
from no_such_table nst
where nst.id = 1001 -- dummy sql comment