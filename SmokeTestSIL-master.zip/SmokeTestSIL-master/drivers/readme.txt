mac-chromedriver - ChromeDriver 74.0.3729.6 for MacOSX (64-bit)
- supports Chrome 74

linux-chromedriver - ChromeDriver 74.0.3729.6 for Linux (64-bit)
- supports Chrome 74
